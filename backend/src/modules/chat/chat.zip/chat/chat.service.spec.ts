jest.mock('../../core/prisma/prisma.service', () => ({
  PrismaService: class {},
}));

jest.mock('../employee/employee.service', () => ({
  EmployeeService: class {},
}));

jest.mock('./chat-session.service', () => ({
  ChatSessionService: class {},
}));

jest.mock('../escalation/escalation.service', () => ({
  EscalationService: class {},
}));

jest.mock('../../content/hr-content.service', () => ({
  HrContentService: class {},
}));

jest.mock('../leave/leave.service', () => ({
  LeaveService: class {},
}));

import { ConversationService } from './chat.service';
import { LeaveService } from '../leave/leave.service';
import { MENU_IDS, MENU_SELECTION_IDS } from './menu.config';

describe('ConversationService', () => {
  let service: ConversationService;
  let employeeService: { findByPhoneNumber: jest.Mock };
  let prisma: { chatMessage: { create: jest.Mock }; chatSession: any };
  let chatSessionService: {
    getOrCreateSession: jest.Mock;
    updateState: jest.Mock;
    touch: jest.Mock;
  };
  let menuReplyBuilder: {
    getSelection: jest.Mock;
    buildMenuReply: jest.Mock;
  };
  let escalationService: {
    createOrGetActiveEscalation: jest.Mock;
  };
  let leaveService: {
    getLeaveBalanceByPhone: jest.Mock;
  };
  let hrContentService: {
    get: jest.Mock;
    getAnswer: jest.Mock;
    exists: jest.Mock;
  };

  beforeEach(() => {
    employeeService = { findByPhoneNumber: jest.fn() };
    prisma = {
      chatMessage: { create: jest.fn() },
      chatSession: {
        findUnique: jest.fn(),
      },
    };
    chatSessionService = {
      getOrCreateSession: jest.fn(),
      updateState: jest.fn(),
      touch: jest.fn(),
    };
    menuReplyBuilder = {
      getSelection: jest.fn(),
      buildMenuReply: jest.fn(),
    };
    escalationService = {
      createOrGetActiveEscalation: jest.fn(),
    };

    leaveService = {
      getLeaveBalanceByPhone: jest.fn(),
    };

    hrContentService = {
      get: jest.fn(),
      getAnswer: jest.fn(),
      exists: jest.fn(),
    };

    service = new ConversationService(
      employeeService as any,
      prisma as any,
      chatSessionService as any,
      menuReplyBuilder as any,
      escalationService as any,
      hrContentService as any,
      leaveService as any,
    );
  });

  it('handles a known active employee', async () => {
    employeeService.findByPhoneNumber.mockResolvedValue({
      id: 'emp-1',
      status: 'ACTIVE',
    });
    chatSessionService.getOrCreateSession.mockResolvedValue({
      id: 'session-1',
      currentState: 'MAIN_MENU',
    });
    menuReplyBuilder.getSelection.mockReturnValue({
      id: MENU_SELECTION_IDS.LEAVE_BALANCE,
      action: 'open_leave_balance',
    });
    menuReplyBuilder.buildMenuReply.mockReturnValue({
      type: 'menu',
      menuId: MENU_IDS.LEAVE,
      title: 'Leave & Time Off',
      prompt: 'How may we be of service?',
      options: [],
    });

    const response = await service.handleMessage({
      senderPhoneNumber: '+2347044965784',
      input: { kind: 'selection', value: MENU_SELECTION_IDS.LEAVE_BALANCE },
    });

    expect(response.success).toBe(true);
    expect(response.state).toBe('LEAVE_MENU');
    expect(response.action).toBe('leave_menu');
    expect(response.replies[0]).toMatchObject({
      type: 'menu',
      menuId: MENU_IDS.LEAVE,
    });
  });

  it('handles an unknown employee', async () => {
    employeeService.findByPhoneNumber.mockResolvedValue(null);

    const response = await service.handleMessage({
      senderPhoneNumber: '+2347044965784',
      input: { kind: 'text', value: 'hello' },
    });

    expect(response.success).toBe(false);
    expect(response.replies).toEqual([
      { type: 'text', text: 'Employee not found.' },
    ]);
  });

  it('handles an inactive employee', async () => {
    employeeService.findByPhoneNumber.mockResolvedValue({
      id: 'emp-2',
      status: 'INACTIVE',
    });

    const response = await service.handleMessage({
      senderPhoneNumber: '+2347044965784',
      input: { kind: 'text', value: 'hello' },
    });

    expect(response.success).toBe(false);
    expect(response.replies).toEqual([
      {
        type: 'text',
        text: 'Your employee account is not active. Please contact HR.',
      },
    ]);
  });

  it('returns the main menu', async () => {
    employeeService.findByPhoneNumber.mockResolvedValue({
      id: 'emp-3',
      status: 'ACTIVE',
    });
    chatSessionService.getOrCreateSession.mockResolvedValue({
      id: 'session-3',
      currentState: 'MAIN_MENU',
    });
    menuReplyBuilder.buildMenuReply.mockReturnValue({
      type: 'menu',
      menuId: MENU_IDS.MAIN,
      title: 'HR Services',
      prompt: 'How may we be of service?',
      options: [],
    });

    const response = await service.handleMessage({
      senderPhoneNumber: '+2347044965784',
      input: { kind: 'selection', value: 'menu' },
    });

    expect(response.success).toBe(true);
    expect(response.replies[0]).toMatchObject({
      type: 'menu',
      menuId: MENU_IDS.MAIN,
    });
  });

  it('returns to the main menu from a submenu when back is selected', async () => {
    employeeService.findByPhoneNumber.mockResolvedValue({
      id: 'emp-back-1',
      status: 'ACTIVE',
    });
    chatSessionService.getOrCreateSession.mockResolvedValue({
      id: 'session-back-1',
      currentState: 'LEAVE_MENU',
    });
    menuReplyBuilder.buildMenuReply.mockReturnValue({
      type: 'menu',
      menuId: MENU_IDS.MAIN,
      title: 'HR Services',
      prompt: 'How may we be of service?',
      options: [],
    });

    const response = await service.handleMessage({
      senderPhoneNumber: '+2347044965784',
      input: { kind: 'text', value: 'back' },
    });

    expect(chatSessionService.updateState).toHaveBeenCalledWith(
      'session-back-1',
      'MAIN_MENU',
    );
    expect(response.state).toBe('MAIN_MENU');
    expect(response.action).toBe('main_menu');
    expect(response.replies[0]).toEqual({
      type: 'menu',
      menuId: MENU_IDS.MAIN,
      title: 'HR Services',
      prompt: 'How may we be of service?',
      options: [],
    });
  });

  it('returns to the main menu from the HR queue when back is selected without resolving escalation', async () => {
    employeeService.findByPhoneNumber.mockResolvedValue({
      id: 'emp-back-2',
      status: 'ACTIVE',
    });
    chatSessionService.getOrCreateSession.mockResolvedValue({
      id: 'session-back-2',
      currentState: 'HR_QUEUE',
    });
    menuReplyBuilder.buildMenuReply.mockReturnValue({
      type: 'menu',
      menuId: MENU_IDS.MAIN,
      title: 'HR Services',
      prompt: 'How may we be of service?',
      options: [],
    });

    const response = await service.handleMessage({
      senderPhoneNumber: '+2347044965784',
      input: { kind: 'text', value: 'back' },
    });

    expect(chatSessionService.updateState).toHaveBeenCalledWith(
      'session-back-2',
      'MAIN_MENU',
    );
    expect(
      escalationService.createOrGetActiveEscalation,
    ).not.toHaveBeenCalled();
    expect(response.state).toBe('MAIN_MENU');
    expect(response.replies[0].type).toBe('menu');
  });

  it('handles a deterministic selection', async () => {
    employeeService.findByPhoneNumber.mockResolvedValue({
      id: 'emp-4',
      status: 'ACTIVE',
    });
    chatSessionService.getOrCreateSession.mockResolvedValue({
      id: 'session-4',
      currentState: 'MAIN_MENU',
    });
    menuReplyBuilder.getSelection.mockReturnValue({
      id: MENU_SELECTION_IDS.BENEFITS,
      action: 'open_benefits',
    });
    menuReplyBuilder.buildMenuReply.mockReturnValue({
      type: 'menu',
      menuId: MENU_IDS.BENEFITS,
      title: 'Benefits',
      prompt: 'How may we be of service?',
      options: [],
    });

    const response = await service.handleMessage({
      senderPhoneNumber: '+2347044965784',
      input: { kind: 'selection', value: '2' },
    });

    expect(response.success).toBe(true);
    expect(response.state).toBe('BENEFITS_MENU');
    expect(response.replies[0]).toMatchObject({
      type: 'menu',
      menuId: MENU_IDS.BENEFITS,
    });
  });

  it('passes numeric menu input through the deterministic selection flow', async () => {
    employeeService.findByPhoneNumber.mockResolvedValue({
      id: 'emp-numeric',
      status: 'ACTIVE',
    });
    chatSessionService.getOrCreateSession.mockResolvedValue({
      id: 'session-numeric',
      currentState: 'MAIN_MENU',
    });
    menuReplyBuilder.getSelection.mockReturnValue({
      id: MENU_SELECTION_IDS.LEAVE_BALANCE,
      action: 'open_leave_balance',
    });
    menuReplyBuilder.buildMenuReply.mockReturnValue({
      type: 'menu',
      menuId: MENU_IDS.LEAVE,
      title: 'Leave & Time Off',
      prompt: 'How can we assist you with your leave?',
      options: [],
    });

    const response = await service.handleMessage({
      senderPhoneNumber: '+2347044965784',
      input: { kind: 'text', value: '2' },
    });

    expect(menuReplyBuilder.getSelection).toHaveBeenCalledWith(
      MENU_IDS.MAIN,
      '2',
    );
    expect(response.success).toBe(true);
    expect(response.state).toBe('LEAVE_MENU');
  });

  it('returns static HR content for a Policy FAQ selection', async () => {
    employeeService.findByPhoneNumber.mockResolvedValue({
      id: 'emp-policy',
      status: 'ACTIVE',
    });
    chatSessionService.getOrCreateSession.mockResolvedValue({
      id: 'session-policy',
      currentState: 'POLICY_MENU',
    });
    menuReplyBuilder.getSelection.mockReturnValue({
      id: MENU_SELECTION_IDS.LEAVE_POLICY,
      action: 'show_leave_policy',
    });
    hrContentService.get.mockReturnValue({
      id: 'leave_policy',
      title: 'Leave Policy',
      answer:
        '[HR APPROVAL REQUIRED] Leave policy content has not yet been provided by HR.',
      status: 'PLACEHOLDER',
    });

    const response = await service.handleMessage({
      senderPhoneNumber: '+2347044965784',
      input: { kind: 'selection', value: MENU_SELECTION_IDS.LEAVE_POLICY },
    });

    expect(menuReplyBuilder.getSelection).toHaveBeenCalledWith(
      MENU_IDS.POLICY,
      MENU_SELECTION_IDS.LEAVE_POLICY,
    );
    expect(hrContentService.get).toHaveBeenCalledWith(
      'policy',
      MENU_SELECTION_IDS.LEAVE_POLICY,
    );
    expect(response.success).toBe(true);
    expect(response.state).toBe('POLICY_MENU');
    expect(response.action).toBe('show_leave_policy');
    expect(response.message).toBe(
      '[HR APPROVAL REQUIRED] Leave policy content has not yet been provided by HR.',
    );
    expect(response.replies).toEqual([
      {
        type: 'text',
        text: '[HR APPROVAL REQUIRED] Leave policy content has not yet been provided by HR.',
      },
    ]);
  });

  it('returns a content-not-found response when a Policy FAQ item has no static content', async () => {
    employeeService.findByPhoneNumber.mockResolvedValue({
      id: 'emp-policy-missing-content',
      status: 'ACTIVE',
    });
    chatSessionService.getOrCreateSession.mockResolvedValue({
      id: 'session-policy-missing-content',
      currentState: 'POLICY_MENU',
    });
    menuReplyBuilder.getSelection.mockReturnValue({
      id: MENU_SELECTION_IDS.LEAVE_POLICY,
      action: 'show_leave_policy',
    });
    hrContentService.get.mockReturnValue(undefined);

    const response = await service.handleMessage({
      senderPhoneNumber: '+2347044965784',
      input: { kind: 'selection', value: MENU_SELECTION_IDS.LEAVE_POLICY },
    });

    expect(hrContentService.get).toHaveBeenCalledWith(
      'policy',
      MENU_SELECTION_IDS.LEAVE_POLICY,
    );
    expect(response.state).toBe('POLICY_MENU');
    expect(response.action).toBe('content_not_found');
  });

  it('returns static HR content for a Health Insurance selection', async () => {
    employeeService.findByPhoneNumber.mockResolvedValue({
      id: 'emp-health-insurance',
      status: 'ACTIVE',
    });
    chatSessionService.getOrCreateSession.mockResolvedValue({
      id: 'session-health-insurance',
      currentState: 'POLICY_MENU',
    });
    menuReplyBuilder.getSelection.mockReturnValue({
      id: MENU_SELECTION_IDS.HEALTH_INSURANCE,
      action: 'show_health_insurance',
    });
    hrContentService.get.mockReturnValue({
      id: 'health_insurance',
      title: 'Health Insurance',
      answer:
        '[HR APPROVAL REQUIRED] Health Insurance information has not yet been provided by HR.',
      status: 'PLACEHOLDER',
    });

    const response = await service.handleMessage({
      senderPhoneNumber: '+2347044965784',
      input: {
        kind: 'selection',
        value: MENU_SELECTION_IDS.HEALTH_INSURANCE,
      },
    });

    expect(menuReplyBuilder.getSelection).toHaveBeenCalledWith(
      MENU_IDS.POLICY,
      MENU_SELECTION_IDS.HEALTH_INSURANCE,
    );
    expect(hrContentService.get).toHaveBeenCalledWith(
      'policy',
      MENU_SELECTION_IDS.HEALTH_INSURANCE,
    );
    expect(response.success).toBe(true);
    expect(response.state).toBe('POLICY_MENU');
    expect(response.action).toBe('show_health_insurance');
    expect(response.message).toBe(
      '[HR APPROVAL REQUIRED] Health Insurance information has not yet been provided by HR.',
    );
    expect(response.replies).toEqual([
      {
        type: 'text',
        text: '[HR APPROVAL REQUIRED] Health Insurance information has not yet been provided by HR.',
      },
    ]);
  });

  it('returns the employee leave balance through LeaveService', async () => {
    employeeService.findByPhoneNumber.mockResolvedValue({
      id: 'emp-leave-balance',
      status: 'ACTIVE',
    });
    chatSessionService.getOrCreateSession.mockResolvedValue({
      id: 'session-leave-balance',
      currentState: 'LEAVE_MENU',
    });
    menuReplyBuilder.getSelection.mockReturnValue({
      id: MENU_SELECTION_IDS.LEAVE_BALANCE,
      action: 'open_leave_balance',
    });
    leaveService.getLeaveBalanceByPhone.mockResolvedValue({
      status: 'available',
      balance: { remainingDays: 12 },
    });

    const response = await service.handleMessage({
      senderPhoneNumber: '+2347044965784',
      input: { kind: 'selection', value: MENU_SELECTION_IDS.LEAVE_BALANCE },
    });

    expect(leaveService.getLeaveBalanceByPhone).toHaveBeenCalledWith(
      '+2347044965784',
    );
    expect(response.success).toBe(true);
    expect(response.state).toBe('LEAVE_MENU');
    expect(response.action).toBe('open_leave_balance');
    expect(response.message).toBe('You have 12 leave days remaining.');
    expect(response.replies).toEqual([
      { type: 'text', text: 'You have 12 leave days remaining.' },
    ]);
  });

  it('returns a safe message when the leave balance is unavailable', async () => {
    employeeService.findByPhoneNumber.mockResolvedValue({
      id: 'emp-leave-balance-unavailable',
      status: 'ACTIVE',
    });
    chatSessionService.getOrCreateSession.mockResolvedValue({
      id: 'session-leave-balance-unavailable',
      currentState: 'LEAVE_MENU',
    });
    menuReplyBuilder.getSelection.mockReturnValue({
      id: MENU_SELECTION_IDS.LEAVE_BALANCE,
      action: 'open_leave_balance',
    });
    leaveService.getLeaveBalanceByPhone.mockResolvedValue({
      status: 'unavailable',
    });

    const response = await service.handleMessage({
      senderPhoneNumber: '+2347044965784',
      input: { kind: 'selection', value: MENU_SELECTION_IDS.LEAVE_BALANCE },
    });

    expect(response.action).toBe('leave_balance_unavailable');
    expect(response.message).toBe(
      'Your leave balance is currently unavailable. Please contact HR for assistance.',
    );
  });

  it('returns static HR content for Learn About Leave', async () => {
    employeeService.findByPhoneNumber.mockResolvedValue({
      id: 'emp-leave-types',
      status: 'ACTIVE',
    });
    chatSessionService.getOrCreateSession.mockResolvedValue({
      id: 'session-leave-types',
      currentState: 'LEAVE_MENU',
    });
    menuReplyBuilder.getSelection.mockReturnValue({
      id: MENU_SELECTION_IDS.LEAVE_TYPES,
      action: 'show_leave_types',
    });
    hrContentService.get.mockReturnValue({
      id: MENU_SELECTION_IDS.LEAVE_TYPES,
      title: 'Leave Types',
      answer:
        '[HR APPROVAL REQUIRED] Leave types content has not yet been provided by HR.',
      status: 'PLACEHOLDER',
    });

    const response = await service.handleMessage({
      senderPhoneNumber: '+2347044965784',
      input: { kind: 'selection', value: MENU_SELECTION_IDS.LEAVE_TYPES },
    });

    expect(hrContentService.get).toHaveBeenCalledWith(
      'leave',
      MENU_SELECTION_IDS.LEAVE_TYPES,
    );
    expect(response.message).toBe(
      '[HR APPROVAL REQUIRED] Leave types content has not yet been provided by HR.',
    );
    expect(response.action).toBe('show_leave_types');
  });

  it('routes selections within the Leave menu', async () => {
    employeeService.findByPhoneNumber.mockResolvedValue({
      id: 'emp-leave',
      status: 'ACTIVE',
    });
    chatSessionService.getOrCreateSession.mockResolvedValue({
      id: 'session-leave',
      currentState: 'LEAVE_MENU',
    });
    menuReplyBuilder.getSelection.mockReturnValue({
      id: MENU_SELECTION_IDS.LEAVE_TYPES,
      action: 'show_leave_types',
    });

    const response = await service.handleMessage({
      senderPhoneNumber: '+2347044965784',
      input: { kind: 'selection', value: MENU_SELECTION_IDS.LEAVE_TYPES },
    });

    expect(response.state).toBe('LEAVE_MENU');
    expect(response.action).toBe('show_leave_types');
  });

  it('returns static HR content for a Benefits selection', async () => {
    employeeService.findByPhoneNumber.mockResolvedValue({
      id: 'emp-benefits',
      status: 'ACTIVE',
    });
    chatSessionService.getOrCreateSession.mockResolvedValue({
      id: 'session-benefits',
      currentState: 'BENEFITS_MENU',
    });
    menuReplyBuilder.getSelection.mockReturnValue({
      id: MENU_SELECTION_IDS.PENSION,
      action: 'show_pension',
    });
    hrContentService.get.mockReturnValue({
      id: 'pension',
      title: 'Pension',
      answer:
        '[HR APPROVAL REQUIRED] Pension information has not yet been provided by HR.',
      status: 'PLACEHOLDER',
    });

    const response = await service.handleMessage({
      senderPhoneNumber: '+2347044965784',
      input: { kind: 'selection', value: MENU_SELECTION_IDS.PENSION },
    });

    expect(menuReplyBuilder.getSelection).toHaveBeenCalledWith(
      MENU_IDS.BENEFITS,
      MENU_SELECTION_IDS.PENSION,
    );
    expect(hrContentService.get).toHaveBeenCalledWith(
      'benefits',
      MENU_SELECTION_IDS.PENSION,
    );
    expect(response.success).toBe(true);
    expect(response.state).toBe('BENEFITS_MENU');
    expect(response.action).toBe('show_pension');
    expect(response.message).toBe(
      '[HR APPROVAL REQUIRED] Pension information has not yet been provided by HR.',
    );
    expect(response.replies).toEqual([
      {
        type: 'text',
        text: '[HR APPROVAL REQUIRED] Pension information has not yet been provided by HR.',
      },
    ]);
  });

  it('returns a content-not-found response when a Benefits item has no static content', async () => {
    employeeService.findByPhoneNumber.mockResolvedValue({
      id: 'emp-benefits-missing-content',
      status: 'ACTIVE',
    });
    chatSessionService.getOrCreateSession.mockResolvedValue({
      id: 'session-benefits-missing-content',
      currentState: 'BENEFITS_MENU',
    });
    menuReplyBuilder.getSelection.mockReturnValue({
      id: MENU_SELECTION_IDS.PENSION,
      action: 'show_pension',
    });
    hrContentService.get.mockReturnValue(undefined);

    const response = await service.handleMessage({
      senderPhoneNumber: '+2347044965784',
      input: { kind: 'selection', value: MENU_SELECTION_IDS.PENSION },
    });

    expect(hrContentService.get).toHaveBeenCalledWith(
      'benefits',
      MENU_SELECTION_IDS.PENSION,
    );
    expect(response.state).toBe('BENEFITS_MENU');
    expect(response.action).toBe('content_not_found');
  });

  it('returns to the main menu from the Policy FAQ menu when back is selected', async () => {
    employeeService.findByPhoneNumber.mockResolvedValue({
      id: 'emp-policy-back',
      status: 'ACTIVE',
    });
    chatSessionService.getOrCreateSession.mockResolvedValue({
      id: 'session-policy-back',
      currentState: 'POLICY_MENU',
    });
    menuReplyBuilder.buildMenuReply.mockReturnValue({
      type: 'menu',
      menuId: MENU_IDS.MAIN,
      title: 'HR Services',
      prompt: 'How may we be of service?',
      options: [],
    });

    const response = await service.handleMessage({
      senderPhoneNumber: '+2347044965784',
      input: { kind: 'selection', value: 'back' },
    });

    expect(chatSessionService.updateState).toHaveBeenCalledWith(
      'session-policy-back',
      'MAIN_MENU',
    );
    expect(response.state).toBe('MAIN_MENU');
    expect(response.menu?.menuId).toBe(MENU_IDS.MAIN);
  });

  it('returns to the main menu from the Leave menu when back is selected', async () => {
    employeeService.findByPhoneNumber.mockResolvedValue({
      id: 'emp-leave-back',
      status: 'ACTIVE',
    });
    chatSessionService.getOrCreateSession.mockResolvedValue({
      id: 'session-leave-back',
      currentState: 'LEAVE_MENU',
    });
    menuReplyBuilder.buildMenuReply.mockReturnValue({
      type: 'menu',
      menuId: MENU_IDS.MAIN,
      title: 'HR Services',
      prompt: 'How may we be of service?',
      options: [],
    });

    const response = await service.handleMessage({
      senderPhoneNumber: '+2347044965784',
      input: { kind: 'selection', value: 'back' },
    });

    expect(chatSessionService.updateState).toHaveBeenCalledWith(
      'session-leave-back',
      'MAIN_MENU',
    );
    expect(response.state).toBe('MAIN_MENU');
    expect(response.menu?.menuId).toBe(MENU_IDS.MAIN);
  });

  it('returns to the main menu from the Benefits menu when back is selected', async () => {
    employeeService.findByPhoneNumber.mockResolvedValue({
      id: 'emp-benefits-back',
      status: 'ACTIVE',
    });
    chatSessionService.getOrCreateSession.mockResolvedValue({
      id: 'session-benefits-back',
      currentState: 'BENEFITS_MENU',
    });
    menuReplyBuilder.buildMenuReply.mockReturnValue({
      type: 'menu',
      menuId: MENU_IDS.MAIN,
      title: 'HR Services',
      prompt: 'How may we be of service?',
      options: [],
    });

    const response = await service.handleMessage({
      senderPhoneNumber: '+2347044965784',
      input: { kind: 'selection', value: 'back' },
    });

    expect(chatSessionService.updateState).toHaveBeenCalledWith(
      'session-benefits-back',
      'MAIN_MENU',
    );
    expect(response.state).toBe('MAIN_MENU');
    expect(response.menu?.menuId).toBe(MENU_IDS.MAIN);
  });

  it('returns to the main menu from the Employment & Documents menu when back is selected', async () => {
    employeeService.findByPhoneNumber.mockResolvedValue({
      id: 'emp-verification-back',
      status: 'ACTIVE',
    });
    chatSessionService.getOrCreateSession.mockResolvedValue({
      id: 'session-verification-back',
      currentState: 'VERIFICATION_MENU',
    });
    menuReplyBuilder.buildMenuReply.mockReturnValue({
      type: 'menu',
      menuId: MENU_IDS.MAIN,
      title: 'HR Services',
      prompt: 'How may we be of service?',
      options: [],
    });

    const response = await service.handleMessage({
      senderPhoneNumber: '+2347044965784',
      input: { kind: 'selection', value: 'back' },
    });

    expect(chatSessionService.updateState).toHaveBeenCalledWith(
      'session-verification-back',
      'MAIN_MENU',
    );
    expect(response.state).toBe('MAIN_MENU');
    expect(response.menu?.menuId).toBe(MENU_IDS.MAIN);
  });

  it('returns a fallback reply when the selection is not recognized', async () => {
    employeeService.findByPhoneNumber.mockResolvedValue({
      id: 'emp-5',
      status: 'ACTIVE',
    });
    chatSessionService.getOrCreateSession.mockResolvedValue({
      id: 'session-5',
      currentState: 'MAIN_MENU',
    });
    menuReplyBuilder.getSelection.mockReturnValue(undefined);
    menuReplyBuilder.buildMenuReply.mockReturnValue({
      type: 'menu',
      menuId: MENU_IDS.MAIN,
      title: 'HR Services',
      prompt: 'How may we be of service?',
      options: [],
    });

    const response = await service.handleMessage({
      senderPhoneNumber: '+2347044965784',
      input: { kind: 'text', value: 'not-a-valid-choice' },
    });

    expect(response.success).toBe(true);
    expect(response.action).toBe('fallback');
    expect(response.replies[0]).toEqual({
      type: 'text',
      text: 'I could not match that selection. Please choose one of the available options.',
    });
  });

  it('handles a Talk to HR selection from a submenu with a renderable reply', async () => {
    employeeService.findByPhoneNumber.mockResolvedValue({
      id: 'emp-6',
      status: 'ACTIVE',
    });
    chatSessionService.getOrCreateSession.mockResolvedValue({
      id: 'session-6',
      currentState: 'POLICY_MENU',
    });
    escalationService.createOrGetActiveEscalation.mockResolvedValue({
      escalationId: 'esc-1',
      status: 'OPEN',
      queuePosition: 1,
      hrBusy: false,
    });

    const response = await service.handleMessage({
      senderPhoneNumber: '+2347044965784',
      input: { kind: 'selection', value: MENU_SELECTION_IDS.TALK_TO_HR },
    });

    expect(response.success).toBe(true);
    expect(response.replies[0]).toEqual({
      type: 'text',
      text: 'Your request has been added to the HR queue. You are number 1 in the queue. An HR representative will attend to you shortly.',
    });
  });

  it('handles numeric Talk to HR selection from a submenu', async () => {
    employeeService.findByPhoneNumber.mockResolvedValue({
      id: 'emp-numeric-talk-to-hr',
      status: 'ACTIVE',
    });
    chatSessionService.getOrCreateSession.mockResolvedValue({
      id: 'session-numeric-talk-to-hr',
      currentState: 'POLICY_MENU',
    });
    menuReplyBuilder.getSelection.mockReturnValue({
      id: MENU_SELECTION_IDS.TALK_TO_HR,
      action: 'talk_to_hr',
    });
    escalationService.createOrGetActiveEscalation.mockResolvedValue({
      escalationId: 'esc-numeric-1',
      status: 'OPEN',
      queuePosition: 1,
      hrBusy: false,
    });

    const response = await service.handleMessage({
      senderPhoneNumber: '+2347044965784',
      input: { kind: 'text', value: '8' },
    });

    expect(menuReplyBuilder.getSelection).toHaveBeenCalledWith(
      MENU_IDS.POLICY,
      '8',
    );
    expect(escalationService.createOrGetActiveEscalation).toHaveBeenCalled();
    expect(response.success).toBe(true);
    expect(response.action).toBe('talk_to_hr');
    expect(response.state).toBe('HR_QUEUE');
  });

  it('does not escalate Talk to HR from the main menu', async () => {
    employeeService.findByPhoneNumber.mockResolvedValue({
      id: 'emp-main-talk-to-hr',
      status: 'ACTIVE',
    });
    chatSessionService.getOrCreateSession.mockResolvedValue({
      id: 'session-main-talk-to-hr',
      currentState: 'MAIN_MENU',
    });
    menuReplyBuilder.getSelection.mockReturnValue(undefined);
    menuReplyBuilder.buildMenuReply.mockReturnValue({
      type: 'menu',
      menuId: MENU_IDS.MAIN,
      title: 'HR Services',
      prompt: 'How may we be of service?',
      options: [],
    });

    const response = await service.handleMessage({
      senderPhoneNumber: '+2347044965784',
      input: {
        kind: 'selection',
        value: MENU_SELECTION_IDS.TALK_TO_HR,
      },
    });

    expect(
      escalationService.createOrGetActiveEscalation,
    ).not.toHaveBeenCalled();
    expect(response.state).toBe('MAIN_MENU');
    expect(response.action).toBe('fallback');
  });

  it('provides renderable replies across branches', async () => {
    employeeService.findByPhoneNumber.mockResolvedValue({
      id: 'emp-7',
      status: 'ACTIVE',
    });
    chatSessionService.getOrCreateSession.mockResolvedValue({
      id: 'session-7',
      currentState: 'MAIN_MENU',
    });
    menuReplyBuilder.buildMenuReply.mockReturnValue({
      type: 'menu',
      menuId: MENU_IDS.MAIN,
      title: 'HR Services',
      prompt: 'How may we be of service?',
      options: [],
    });

    const response = await service.handleMessage({
      senderPhoneNumber: '+2347044965784',
      input: { kind: 'selection', value: 'menu' },
    });

    expect(Array.isArray(response.replies)).toBe(true);
    expect(response.replies.length).toBeGreaterThan(0);
    expect(response.replies[0].type).toBe('menu');
  });
});
